//  Hungry_Cells
//
//  Created by Roman Filippov on 26/09/15.
//
//

#import "cocos2d.h"
@interface Level : CCLayer

+ (CCScene*) scene;

@end
